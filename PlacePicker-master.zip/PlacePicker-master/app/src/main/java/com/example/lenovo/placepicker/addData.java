package com.example.lenovo.placepicker;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Created by Lenovo on 14-03-2017.
 */
public class addData extends Activity {
}
